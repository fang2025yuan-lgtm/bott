#!/bin/bash
set -e

echo "================================================="
echo "   UFQ JAMOA BOT - THE ULTIMATE DEPLOY (V9)      "
echo "================================================="

cd /home/ubuntu/UFQ_BOT_V9_FINAL

echo ""
echo "Botni ishga tushirish uchun ma'lumotlarni kiriting:"
read -p "1. Telegram Bot Tokenini kiriting: " bot_token
read -p "2. Bosh Prezidentning Telegram ID raqamini kiriting: " admin_id

cat << EOF > /home/ubuntu/UFQ_BOT_V9_FINAL/.env
BOT_TOKEN=$bot_token
ADMIN_ID=$admin_id
EOF

echo ">>> Eski xizmatlar to'xtatilmoqda..."
sudo systemctl stop ufq-bot 2>/dev/null || true
if command -v pm2 &> /dev/null; then
    pm2 stop all 2>/dev/null || true
    pm2 delete all 2>/dev/null || true
    pm2 save --force 2>/dev/null || true
fi

echo ">>> Python, Redis va kerakli paketlar o'rnatilmoqda..."
sudo apt-get update -y
sudo apt-get install -y python3-venv python3-pip redis-server

sudo systemctl enable redis-server
sudo systemctl start redis-server

rm -rf venv
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

echo ">>> Fayl huquqlari to'g'rilanmoqda..."
sudo chown -R ubuntu:ubuntu /home/ubuntu/UFQ_BOT_V9_FINAL

echo ">>> Tizim xizmati (Systemd) o'rnatilmoqda..."
cat << EOF | sudo tee /etc/systemd/system/ufq-bot.service
[Unit]
Description=UFQ Jamoa Bot
After=network.target redis-server.service

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/UFQ_BOT_V9_FINAL
ExecStart=/home/ubuntu/UFQ_BOT_V9_FINAL/venv/bin/python -m bot.main
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable ufq-bot
sudo systemctl restart ufq-bot

echo ">>> Tizim tekshirilmoqda..."
sleep 3
if ! sudo systemctl is-active --quiet ufq-bot; then
    echo "❌ XATOLIK YUZ BERDI!"
    sudo journalctl -u ufq-bot -n 20 --no-pager
else
    echo "========================================================="
    echo " ✅ BOT ISHGA TUSHDI! Telegramga kirib /start bosing."
    echo "========================================================="
fi
